public class Main {
    constructor() {
        this.students = new Map();
    }

    // Validate student input
    validateStudentInput(id, name, marks) {
        if (typeof id !== "string" || typeof name !== "string" || typeof marks !== "number") {
            throw this.createError("E001", "Validation Error: ID and Name must be strings, and Marks must be a number.");
        }
        if (marks < 0 || marks > 100) {
            throw this.createError("E002", "Validation Error: Marks must be between 0 and 100.");
        }
    }

    // Create standardized error object
    createError(code, message) {
        return { code, message, timestamp: new Date().toISOString() };
    }

    // Insert a new student
    insertStudent(id, name, marks) {
        try {
            this.validateStudentInput(id, name, marks);
            if (this.students.has(id)) {
                throw this.createError("E003", `Duplicate ID Error: A student with ID ${id} already exists.`);
            }
            this.students.set(id, { name, marks });
            console.log(`Student ${name} with ID ${id} added successfully.`);
        } catch (error) {
            this.handleError(error);
        }
    }

    // Delete a student
    deleteStudent(id) {
        try {
            if (typeof id !== "string" || id.trim() === "") {
                throw this.createError("E004", "Validation Error: ID must be a non-empty string.");
            }
            if (!this.students.has(id)) {
                throw this.createError("E005", `Not Found Error: No student found with ID ${id}.`);
            }
            this.students.delete(id);
            console.log(`Student with ID ${id} deleted successfully.`);
        } catch (error) {
            this.handleError(error);
        }
    }

    // Update a student
    updateStudent(id, newName, newMarks) {
        try {
            this.validateStudentInput(id, newName, newMarks);
            if (!this.students.has(id)) {
                throw this.createError("E006", `Not Found Error: No student found with ID ${id}.`);
            }
            this.students.set(id, { name: newName, marks: newMarks });
            console.log(`Student with ID ${id} updated successfully.`);
        } catch (error) {
            this.handleError(error);
        }
    }

    // Search for a student
    searchStudent(id) {
        try {
            if (typeof id !== "string" || id.trim() === "") {
                throw this.createError("E007", "Validation Error: ID must be a non-empty string.");
            }
            if (!this.students.has(id)) {
                throw this.createError("E008", `Not Found Error: No student found with ID ${id}.`);
            }
            const student = this.students.get(id);
            console.log(`Student Found: ID: ${id}, Name: ${student.name}, Marks: ${student.marks}`);
        } catch (error) {
            this.handleError(error);
        }
    }

    // Handle error
    handleError(error) {
        if (error.code) {
            console.error(`[${error.timestamp}] Error Code: ${error.code}, Message: ${error.message}`);
        } else {
            console.error(`[${new Date().toISOString()}] Unexpected Error:`, error);
        }
        alert(error.message || "An unexpected error occurred. Please try again.");
    }

    // List all students
    listAllStudents() {
        try {
            if (this.students.size === 0) {
                console.warn("No students in the system.");
                return [];
            }
            return Array.from(this.students.entries()).map(([id, data]) => ({ id, ...data }));
        } catch (error) {
            this.handleError(error);
        }
    }
}

const sm = new StudentManagement();

// Test Case 1: Valid Input - Adding Student
console.log("Test 1: Adding Valid Student");
sm.insertStudent("S001", "Alice", 85);  // Valid input (Expected output: Success message)

// Test Case 2: Duplicate ID Error - Adding Student with Duplicate ID
console.log("\nTest 2: Duplicate ID Error");
sm.insertStudent("S001", "Bob", 90);  // Duplicate ID Error (Expected output: Error code E003)

// Test Case 3: Invalid Input Type - Marks as String
console.log("\nTest 3: Invalid Input Type");
sm.insertStudent("S002", "Charlie", "85");  // Invalid marks type (Expected output: Error code E001)

// Test Case 4: Invalid Marks Range - Marks outside valid range
console.log("\nTest 4: Invalid Marks Range");
sm.insertStudent("S003", "David", 110);  // Invalid marks (Expected output: Error code E002)
sm.insertStudent("S004", "Eva", -5);     // Invalid marks (Expected output: Error code E002)

// Test Case 5: Empty ID (for Delete or Update)
console.log("\nTest 5: Empty ID");
sm.deleteStudent("");   // Empty ID (Expected output: Error code E004)
sm.updateStudent("", "New Name", 80);  // Empty ID (Expected output: Error code E004)

// Test Case 6: Student Not Found (Delete or Update)
console.log("\nTest 6: Student Not Found (Delete/Update)");
sm.deleteStudent("S005");   // Student not found (Expected output: Error code E005)
sm.updateStudent("S005", "New Name", 75); // Student not found (Expected output: Error code E006)

// Test Case 7: Invalid ID Format (for Search)
console.log("\nTest 7: Invalid ID Format (Search)");
sm.searchStudent("");  // Invalid ID format (Expected output: Error code E007)

// Test Case 8: Student Not Found (Search)
console.log("\nTest 8: Student Not Found (Search)");
sm.searchStudent("S006");  // Student not found (Expected output: Error code E008)

// Test Case 9: Empty List of Students
console.log("\nTest 9: Empty List of Students");
sm.deleteStudent("S001"); // Delete all students
console.log(sm.listAllStudents());  // Empty list (Expected output: No students in the system warning)

// Test Case 10: Valid Update (Update Existing Student)
        console.log("\nTest 10: Valid Update");
sm.insertStudent("S007", "George", 78);  // Adding student for update
sm.updateStudent("S007", "George Updated", 85); // Update success (Expected output: Success message)
